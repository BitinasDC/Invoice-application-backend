package lt.codeacademy.invoice.entities;

public enum ERole {
	ROLE_USER,
	ROLE_MANAGER,
	ROLE_ADMIN

}
