package lt.codeacademy.invoice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvoiceReactSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run( InvoiceReactSpringApplication.class, args );
	}

}